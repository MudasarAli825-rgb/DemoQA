using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System.Threading;
using DemoQA;

namespace Tests
{
    public class Tests
    {
        public IWebDriver driver;

        [SetUp]
        public void Setup()
        {
       
           driver = new ChromeDriver(@"D:\chromedriver");
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://demoqa.com/");
        }

        [Test]
        public void FirstCase()
        {
          
            DemoQAPage Demo = new DemoQAPage(driver);
            Demo.FindandClickForms();
            Thread.Sleep(3000);
            Demo.FindandClickPracticeForm();
            Thread.Sleep(3000);
            
            Demo.FindandsetFirstName("Mudasar");
            Demo.FindandsetLastName("Ali");
            Demo.setGenderMale();
            Demo.setContactNumber("1234567890");
            Demo.clickSubmitButton();
            Thread.Sleep(3000);
            Demo.verifyfromsubmit();
            Thread.Sleep(3000);
                              
        }
        [Test]
        public void SecondCase()
        {         
            DemoQAPage Demo = new DemoQAPage(driver);
            Demo.FindandClickForms();
            Thread.Sleep(3000);
            Demo.FindandClickPracticeForm();
            Demo.clickSubmitButton();
            Thread.Sleep(3000);
            Demo.VerfiyRequiredFields();
        }
        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}