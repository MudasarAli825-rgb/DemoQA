﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoQA
{
    public class DemoQAPage
    {
        private IWebDriver driver;

        public DemoQAPage(IWebDriver driver)
        {
            this.driver = driver;
        }
       
        public void FindandClickForms()
        {
            IWebElement forms = driver.FindElement(By.XPath("//*[@id='app']/div/div/div[2]/div/div[2]/div/div[3]"));
            forms.Click();
        }
        public void FindandClickPracticeForm()
        {
            IWebElement Paactice = driver.FindElement(By.XPath("//span[contains(@class,'text') and contains(text(),'Practice Form')]"));
             Paactice.Click();
        }
        public void FindandsetFirstName(string firstname)
        {
            IWebElement FirstName= driver.FindElement(By.Id("firstName"));
            FirstName.SendKeys(firstname);
        }
        public void FindandsetLastName(string lastName)
        {
            IWebElement LastName = driver.FindElement(By.Id("lastName"));
            LastName.SendKeys(lastName);
        }
        public void setGenderMale()
        {
            IWebElement element = driver.FindElement(By.Id("gender-radio-1"));
            Actions actions = new Actions(driver);
           actions.MoveToElement(element).Click().Perform();

        }
        public void setContactNumber(string Cnumber)
        {
            IWebElement ContactNumber = driver.FindElement(By.CssSelector("input[placeholder='Mobile Number']"));
            ContactNumber.SendKeys(Cnumber);
        }
        public void clickSubmitButton()
        {
            IWebElement submitbtn = driver.FindElement(By.Id("submit"));
            submitbtn.Click();
        }
        public void verifyfromsubmit()
        {
            IWebElement subtmitmeaasge = driver.FindElement(By.Id("example-modal-sizes-title-lg"));
            Assert.IsTrue(subtmitmeaasge.Text == "Thanks for submitting the form", "From Not Submited Successfully");
                      
        }
        public void VerfiyRequiredFields()
        {      //get the colour for these fields      
            string firstname= driver.FindElement(By.Id("firstName")).GetCssValue("background-image");                                       
            if (firstname == null)
            {
                Assert.Fail("Last Name is not required field");

            }

            string lastname = driver.FindElement(By.Id("lastName")).GetCssValue("background-image");
            if (lastname == null)
            {
                Assert.Fail("Last Name is not required field");

            }
            IWebElement Gender = driver.FindElement(By.XPath("//label[@class='custom-control-label']"));
            string gendervalue = Gender.GetCssValue("color");
            string expectedgenderclr= "rgba(220, 53, 69, 1)";
            if (gendervalue != expectedgenderclr)
            {
                Assert.Fail("Gender is not required field");

            }
        }



    }
}
